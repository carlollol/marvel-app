##Team Name
#S.W.O.R.D.
#Sentient World Observation and Response Department

##Project Name
Be an Avenger
We can always use more heros!

##Team Members
##Brandon Chang, Carlo Anacta, Jackie Wellons, Wyatt Thomson

##Project Description
Find the Avengers, a map of where our favorite Marvel heros live and where big events take place from the movies.  You can be a hero and volunteer. Then you can also find a sidekick, using a petfinder API to find a pet to adopt.

##Sketch Final Project
see media folder

##API's to be used
ComciVine
Google Maps
VonlunteerMatch
PetFinder

##Tasks
Design Site, mobile first
Make HTML
Make CSS
Make Javascript
